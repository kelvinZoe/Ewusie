﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondCSharpwithNorbet
{
    class Program
    {
        static void Main(string[] args)
        {
            Animal sheep = new Animal();
            Animal cow = new Animal(5);
        }
    }
}
