﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondCSharpwithNorbet
{
   
    class Animal
    {
        public Animal()
        {
            noOfLegs = 2;
            Console.WriteLine();
        }

        public Animal(int noofLegs)
        {
            noOfLegs = noofLegs;
        }
        public int noOfLegs { get; set; }
    }

    
}
