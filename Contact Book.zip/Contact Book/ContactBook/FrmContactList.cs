﻿using ContactBook.Repository;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContactBook
{
    public partial class FrmContactList : Form
    {
        public FrmContactList()
        {
            InitializeComponent();
            var repo = new ContactRepository();
            bvgContactList.DataSource = repo.GetContact();
        }
        

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void ADDbtn_Click(object sender, EventArgs e)
        {
            Form1 add = new Form1();
            add.ShowDialog();
        }

        private void bvgContactList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
