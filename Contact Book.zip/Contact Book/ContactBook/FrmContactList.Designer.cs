﻿namespace ContactBook
{
    partial class FrmContactList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bvgContactList = new System.Windows.Forms.DataGridView();
            this.ADDbtn = new System.Windows.Forms.Button();
            this.EDITbtn = new System.Windows.Forms.Button();
            this.DELETEbtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.bvgContactList)).BeginInit();
            this.SuspendLayout();
            // 
            // bvgContactList
            // 
            this.bvgContactList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bvgContactList.Dock = System.Windows.Forms.DockStyle.Left;
            this.bvgContactList.Location = new System.Drawing.Point(0, 0);
            this.bvgContactList.Name = "bvgContactList";
            this.bvgContactList.Size = new System.Drawing.Size(312, 261);
            this.bvgContactList.TabIndex = 0;
            this.bvgContactList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.bvgContactList_CellContentClick);
            // 
            // ADDbtn
            // 
            this.ADDbtn.Font = new System.Drawing.Font("Lucida Calligraphy", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ADDbtn.Location = new System.Drawing.Point(336, 13);
            this.ADDbtn.Name = "ADDbtn";
            this.ADDbtn.Size = new System.Drawing.Size(96, 40);
            this.ADDbtn.TabIndex = 1;
            this.ADDbtn.Text = "ADD";
            this.ADDbtn.UseVisualStyleBackColor = true;
            this.ADDbtn.Click += new System.EventHandler(this.ADDbtn_Click);
            // 
            // EDITbtn
            // 
            this.EDITbtn.Font = new System.Drawing.Font("Lucida Calligraphy", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EDITbtn.Location = new System.Drawing.Point(336, 79);
            this.EDITbtn.Name = "EDITbtn";
            this.EDITbtn.Size = new System.Drawing.Size(96, 40);
            this.EDITbtn.TabIndex = 2;
            this.EDITbtn.Text = "EDIT";
            this.EDITbtn.UseVisualStyleBackColor = true;
            // 
            // DELETEbtn
            // 
            this.DELETEbtn.Font = new System.Drawing.Font("Lucida Calligraphy", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DELETEbtn.Location = new System.Drawing.Point(336, 149);
            this.DELETEbtn.Name = "DELETEbtn";
            this.DELETEbtn.Size = new System.Drawing.Size(96, 39);
            this.DELETEbtn.TabIndex = 3;
            this.DELETEbtn.Text = "DELETE";
            this.DELETEbtn.UseVisualStyleBackColor = true;
            this.DELETEbtn.Click += new System.EventHandler(this.button3_Click);
            // 
            // FrmContactList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(444, 261);
            this.Controls.Add(this.DELETEbtn);
            this.Controls.Add(this.EDITbtn);
            this.Controls.Add(this.ADDbtn);
            this.Controls.Add(this.bvgContactList);
            this.Name = "FrmContactList";
            this.Text = "FrmContactList";
            ((System.ComponentModel.ISupportInitialize)(this.bvgContactList)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView bvgContactList;
        private System.Windows.Forms.Button ADDbtn;
        private System.Windows.Forms.Button EDITbtn;
        private System.Windows.Forms.Button DELETEbtn;
    }
}