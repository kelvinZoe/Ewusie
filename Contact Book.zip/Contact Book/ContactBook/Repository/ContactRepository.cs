﻿using ContactBook.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactBook.Repository
{
    public class ContactRepository
    {
        public List<Contacts> Contact { get; private set; }
        
        public ContactRepository()
        {
            Contact = new List<Contacts>();
            for(int i = 0; i<100; i++)
            {
                var c = new Contacts();
                c.FirstName = "first name" + i;
                c.LastName = "last name" + i;
                c.OtherName = "other name" + i;
                c.PhoneNumber = "phone number" + i;
                c.Group = "group " + i;

                Contact.Add(c);
            }
        }

        public void AddContact(Contacts contact)
        {
            Contact.Add(contact);
            Console.WriteLine(Contact.Count());
        }

        public void DeleteContact(Contacts contact)
        {
            Contact.Remove(contact);
        }

        public void EditContact()
        {

        }

        public List<Contacts> GetContact()
        {
            return Contact;
        }
    }
}
