﻿using ContactBook.Models;
using ContactBook.Repository;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContactBook
{
    public partial class Form1 : Form
    {
        ContactRepository repo = new ContactRepository();
        Contacts user = new Contacts();
        //FrmContactList cl = new FrmContactList(); 
        public Form1()
        {
            InitializeComponent();

            user.FirstName = fnametxt.Text;
            user.LastName = lnametxt.Text;
            user.OtherName = OtherNametxt.Text;
            user.Group = Groupcmb.Text;
            user.PhoneNumber = PhoneNumbertxt.Text;

            /*fnametxt.Text = "Ella";
            lnametxt.Text = "Dadzie";
            OtherNametxt.Text = "Kwebu";
            PhoneNumbertxt.Text = "0551515381";
            Groupcmb.SelectedIndex = 2;*/
        }

        private void lnametxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void cancelbtn_Click(object sender, EventArgs e)
        {
         
            Close();
        }

        private void savebtn_Click(object sender, EventArgs e)
        {
            repo.AddContact(user);
        }

        private void fnametxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void PhoneNumbertxt_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void Groupcmb_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
